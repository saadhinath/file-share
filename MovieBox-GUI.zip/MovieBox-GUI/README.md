# MovieBox-GUI

A custom Python desktop/mobile-sized GUI for the existing MovieBox-Tui Rust repository.

## Important implementation note

The supplied Rust repository is a terminal application, not an HTTP/API server. The GUI therefore adds a small `--json-api` mode to the Rust binary. It communicates through newline-delimited JSON over stdin/stdout, so the existing provider/service code remains the source of real data.

The UI is intentionally a safe visual shell: it does not add new content providers or bypass the repository's existing access controls.

## Features in this build

- Dark 360dp-inspired streaming home screen.
- Floating search bar and category tabs.
- Hero/featured area.
- Live cards and horizontally scrolling rows.
- Trending movie/TV poster rows.
- Fixed Home / Downloads / Me navigation.
- Rust bridge for `ping`, `homepage`, `search`, and `details`.
- Offline placeholders when Rust backend is not built or a provider is unavailable.
- Backend runs as a child process and is stopped automatically with the GUI.

## Requirements

- Python 3.10+
- Tkinter
- Pillow
- Rust/Cargo for the backend build

## Linux/Kali

```bash
sudo apt install python3-tk
cd MovieBox-GUI
python3 -m venv .venv
source .venv/bin/activate
pip install -r frontend/requirements.txt
python scripts/build_backend.py
python frontend/main.py
```

For the low-end Celeron/4 GB machine, keep the Rust release build and use the placeholder image mode; avoid adding large UI frameworks.

## Windows

Install Python and Rust, then:

```powershell
py -m pip install -r frontend\requirements.txt
py scripts\build_backend.py
py frontend\main.py
```

## Backend bridge

The frontend launches:

```text
backend/MovieBox-Tui/target/release/moviebox-tui --json-api
```

Requests are one JSON object per line. Example:

```json
{"id":1,"action":"search","query":"The Eminence in Shadow","page":1}
```

The backend responds with one JSON object per line.

## Structure

See the supplied requested architecture under `frontend/`, `protocol/`, `scripts/`, `packaging/`, and `tests/`.

## Limitations of this first working slice

- Tkinter is used for a lightweight cross-platform desktop implementation, not native Android/iOS.
- Poster/hero images are placeholders to keep the project self-contained and avoid bundling copyrighted artwork.
- Downloads/player/favorites/settings controllers are scaffolded for the next integration pass.
- Live data is currently represented by the requested visual cards; a future backend command can expose live-event data if the Rust repository provides it.

## License

The existing Rust backend keeps its original project license files. New frontend code in this bundle is provided as project glue/UI code.
