import subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]/"backend"/"MovieBox-Tui"
subprocess.run(["cargo","build","--release"],cwd=root,check=True)
print("Backend built successfully.")
