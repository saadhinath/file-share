from pathlib import Path
import shutil, zipfile
root=Path(__file__).resolve().parents[1]
out=root.parent/"MovieBox-GUI-built.zip"
if out.exists(): out.unlink()
with zipfile.ZipFile(out,"w",zipfile.ZIP_DEFLATED) as z:
    for p in root.rglob("*"):
        if p.is_file() and ".git" not in p.parts and "target" not in p.parts:
            z.write(p,p.relative_to(root))
print(out)
