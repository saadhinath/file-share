@echo off
cd /d "%~dp0\..\.."
py -m pip install -r frontend\requirements.txt
py frontend\main.py
