#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/../.."
python3 -m pip install -r frontend/requirements.txt
python3 frontend/main.py
