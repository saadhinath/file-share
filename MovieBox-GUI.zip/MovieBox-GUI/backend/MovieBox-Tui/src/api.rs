use crate::service::MovieBoxService;
use crate::providers::models::ProviderKind;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::io::{self, BufRead, Write};

#[derive(Debug, Deserialize)]
struct Request {
    id: Option<Value>,
    action: String,
    provider: Option<String>,
    query: Option<String>,
    page: Option<usize>,
    subject_id: Option<String>,
    tab_id: Option<String>,
}

#[derive(Debug, Serialize)]
struct Response<T: Serialize> {
    id: Value,
    ok: bool,
    data: Option<T>,
    error: Option<String>,
}

fn reply<T: Serialize>(id: Value, data: Result<T, String>) -> String {
    match data {
        Ok(v) => serde_json::to_string(&Response { id, ok: true, data: Some(v), error: None }).unwrap(),
        Err(e) => serde_json::to_string(&Response::<Value> { id, ok: false, data: None, error: Some(e) }).unwrap(),
    }
}

fn provider(s: Option<&str>) -> ProviderKind {
    s.and_then(ProviderKind::parse).unwrap_or(ProviderKind::MovieBox)
}

pub async fn run() -> io::Result<()> {
    let service = MovieBoxService::new();
    let stdin = io::stdin();
    let mut out = io::BufWriter::new(io::stdout());

    for line in stdin.lock().lines() {
        let line = match line { Ok(v) => v, Err(e) => { writeln!(out, "{}", reply(json!(null), Err::<Value,_>(e.to_string())))?; out.flush()?; continue; } };
        if line.trim().is_empty() { continue; }
        let req: Result<Request, _> = serde_json::from_str(&line);
        let (id, result) = match req {
            Err(e) => (json!(null), Err(e.to_string())),
            Ok(r) => {
                let id = r.id.unwrap_or(json!(null));
                let result: Result<Value, String> = match r.action.as_str() {
                    "ping" => Ok(json!({"version": env!("CARGO_PKG_VERSION")})),
                    "search" => {
                        let q = r.query.unwrap_or_default();
                        match service.search_typed(provider(r.provider.as_deref()), &q, r.page.unwrap_or(1)).await {
                            Ok(items) => serde_json::to_value(items).map_err(|e| e.to_string()),
                            Err(e) => Err(e.to_string()),
                        }
                    },
                    "homepage" => {
                        let tab = r.tab_id.unwrap_or_else(|| "trending".to_string());
                        match service.homepage(&tab, r.page.unwrap_or(1)).await {
                            Ok((items, metrics)) => Ok(json!({"items": items, "metrics": metrics})),
                            Err(e) => Err(e),
                        }
                    },
                    "details" => {
                        let sid = r.subject_id.unwrap_or_default();
                        match service.details_typed(provider(r.provider.as_deref()), &sid).await {
                            Ok(details) => serde_json::to_value(details).map_err(|e| e.to_string()),
                            Err(e) => Err(e.to_string()),
                        }
                    },
                    _ => Err(format!("unknown action: {}", r.action)),
                };
                (id, result)
            }
        };
        writeln!(out, "{}", reply(id, result))?;
        out.flush()?;
    }
    Ok(())
}
