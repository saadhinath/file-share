from dataclasses import dataclass
@dataclass
class Download: title: str; progress: float = 0.0; status: str = 'queued'
