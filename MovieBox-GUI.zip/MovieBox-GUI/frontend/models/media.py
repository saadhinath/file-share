from dataclasses import dataclass
@dataclass
class Media:
    id: str
    title: str
    year: str = ""
    poster_url: str = ""
    media_type: str = "movie"
    provider: str = "moviebox"
