from dataclasses import dataclass
@dataclass
class Stream: url: str; quality: str = ''
