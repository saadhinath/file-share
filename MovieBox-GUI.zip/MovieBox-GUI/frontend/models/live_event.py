from dataclasses import dataclass
@dataclass
class LiveEvent: title: str; start: str; status: str = 'upcoming'
