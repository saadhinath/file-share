from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "assets"
POSTERS = ASSETS / "posters"
BANNERS = ASSETS / "banners"
