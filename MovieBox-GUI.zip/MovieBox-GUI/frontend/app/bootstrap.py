import tkinter as tk
from app.logging_setup import setup_logging
from app.config import WINDOW_WIDTH, WINDOW_HEIGHT, BG
from bridge.backend_manager import BackendManager
from bridge.request_client import BackendClient
from ui.main_window import MainWindow

def run():
    setup_logging()
    root = tk.Tk()
    root.title("MovieBox GUI")
    root.geometry(f"{WINDOW_WIDTH}x{WINDOW_HEIGHT}")
    root.minsize(360, 680)
    root.configure(bg=BG)
    backend = BackendManager()
    backend.start()
    client = BackendClient(backend)
    app = MainWindow(root, client, backend)
    root.protocol("WM_DELETE_WINDOW", lambda: (backend.stop(), root.destroy()))
    root.mainloop()
