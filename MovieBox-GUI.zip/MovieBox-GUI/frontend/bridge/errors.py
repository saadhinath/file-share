class BackendError(RuntimeError): pass
