import threading
class BackendClient:
    def __init__(self, manager):
        self.manager = manager
    def _call(self, action, callback=None, **kwargs):
        def work():
            response = self.manager.request(action, **kwargs)
            if callback: callback(response)
        threading.Thread(target=work, daemon=True).start()
    def ping(self, callback): self._call("ping", callback)
    def homepage(self, tab_id, callback, page=1): self._call("homepage", callback, tab_id=tab_id, page=page)
    def search(self, query, callback, page=1): self._call("search", callback, query=query, page=page)
    def details(self, subject_id, callback, provider="moviebox"): self._call("details", callback, subject_id=subject_id, provider=provider)
