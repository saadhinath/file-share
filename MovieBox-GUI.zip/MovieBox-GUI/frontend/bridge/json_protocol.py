import json
def encode(obj): return json.dumps(obj, separators=(',', ':'))
def decode(line): return json.loads(line)
