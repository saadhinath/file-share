class Transport: pass
