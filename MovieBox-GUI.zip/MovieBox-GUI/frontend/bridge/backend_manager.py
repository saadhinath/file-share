import os, subprocess, threading, queue, logging
from pathlib import Path

log = logging.getLogger(__name__)

class BackendManager:
    def __init__(self):
        self.proc = None
        self.stdout = None
        self.stderr = None
        self.lock = threading.Lock()
        self.responses = {}
        self.counter = 0
        self.alive = False
        self.root = Path(__file__).resolve().parents[2]
        env_path = os.environ.get("MOVIEBOX_BACKEND")
        self.binary = Path(env_path) if env_path else None

    def _find_binary(self):
        if self.binary and self.binary.exists():
            return self.binary
        candidates = [
            self.root / "backend" / "MovieBox-Tui" / "target" / "release" / "moviebox-tui",
            self.root / "backend" / "MovieBox-Tui" / "target" / "debug" / "moviebox-tui",
            self.root / "backend" / "MovieBox-Tui" / "target" / "release" / "moviebox-tui.exe",
            self.root / "backend" / "MovieBox-Tui" / "target" / "debug" / "moviebox-tui.exe",
        ]
        for p in candidates:
            if p.exists(): return p
        return None

    def start(self):
        binary = self._find_binary()
        if not binary:
            log.warning("Rust backend binary not found; UI will use offline placeholders.")
            return False
        try:
            self.proc = subprocess.Popen([str(binary), "--json-api"], stdin=subprocess.PIPE,
                                         stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                         text=True, bufsize=1)
            self.alive = True
            threading.Thread(target=self._reader, daemon=True).start()
            threading.Thread(target=self._stderr_reader, daemon=True).start()
            return True
        except Exception:
            log.exception("Could not start Rust backend")
            self.alive = False
            return False

    def _reader(self):
        for line in self.proc.stdout:
            try:
                import json
                obj = json.loads(line)
                ident = str(obj.get("id"))
                with self.lock:
                    q = self.responses.pop(ident, None)
                if q: q.put(obj)
            except Exception:
                log.exception("Bad backend response")
        self.alive = False

    def _stderr_reader(self):
        for line in self.proc.stderr:
            log.debug("backend: %s", line.rstrip())

    def request(self, action, **kwargs):
        if not self.alive or not self.proc:
            return None
        import json
        with self.lock:
            self.counter += 1
            ident = self.counter
            q = queue.Queue(maxsize=1)
            self.responses[str(ident)] = q
        payload = {"id": ident, "action": action, **kwargs}
        try:
            self.proc.stdin.write(json.dumps(payload) + "\n")
            self.proc.stdin.flush()
            return q.get(timeout=30)
        except Exception:
            with self.lock: self.responses.pop(str(ident), None)
            return None

    def stop(self):
        self.alive = False
        if self.proc:
            try: self.proc.terminate()
            except Exception: pass
            self.proc = None
