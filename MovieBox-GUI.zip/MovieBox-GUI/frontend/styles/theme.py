import tkinter as tk
from app.config import TEXT, MUTED, CARD, BG, GREEN
def font(size, bold=False): return ("Inter", size, "bold" if bold else "normal")
def label(parent, text="", size=12, color=TEXT, bold=False, **kw):
    return tk.Label(parent, text=text, fg=color, bg=kw.pop("bg", parent.cget("bg")), font=font(size,bold), **kw)
