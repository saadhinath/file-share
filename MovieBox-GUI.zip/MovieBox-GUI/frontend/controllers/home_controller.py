class HomeController:
    def __init__(self, client): self.client = client
    def load(self, tab, callback): self.client.homepage(tab, callback)
