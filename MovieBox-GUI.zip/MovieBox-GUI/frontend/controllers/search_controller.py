class SearchController:
    def __init__(self, client): self.client = client
    def search(self, query, callback): self.client.search(query, callback)
