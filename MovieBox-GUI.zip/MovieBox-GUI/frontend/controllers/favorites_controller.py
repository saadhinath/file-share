class FavoritesController: pass
