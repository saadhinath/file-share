class SeriesController: pass
