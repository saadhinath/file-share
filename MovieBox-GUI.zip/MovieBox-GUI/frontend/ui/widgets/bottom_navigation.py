# Widget implementation is composed in ui/main_window.py for the thin working slice.
