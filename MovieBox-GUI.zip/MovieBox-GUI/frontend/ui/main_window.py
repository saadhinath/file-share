import tkinter as tk
from PIL import Image, ImageDraw, ImageFont, ImageTk
import urllib.request, io, threading, random
from app.config import *
from styles.theme import font

def placeholder(w,h,text, accent="#28333A"):
    im=Image.new("RGB",(w,h),accent)
    d=ImageDraw.Draw(im)
    for y in range(h):
        t=y/max(1,h-1)
        c=(int(25+40*t),int(35+25*t),int(42+20*t))
        d.line((0,y,w,y),fill=c)
    d.ellipse((w*.55,-h*.25,w*1.25,h*.45),fill="#6b2a28")
    d.text((12,h-42),text[:24],fill="white")
    return ImageTk.PhotoImage(im)

def poster(w,h,text):
    return placeholder(w,h,text,"#20262d")

class HRow(tk.Frame):
    def __init__(self,parent,height=150,bg=BG):
        super().__init__(parent,bg=bg,height=height)
        self.pack_propagate(False)
        self.canvas=tk.Canvas(self,bg=bg,highlightthickness=0,height=height)
        self.inner=tk.Frame(self.canvas,bg=bg)
        self.win=self.canvas.create_window((0,0),window=self.inner,anchor="nw")
        self.canvas.pack(fill="both",expand=True)
        self.inner.bind("<Configure>",lambda e:self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Shift-MouseWheel>",self._wheel)
    def _wheel(self,e): self.canvas.xview_scroll(int(-e.delta/120),"units")

class PosterCard(tk.Frame):
    def __init__(self,parent,title,rank=1,badge="Hindi",command=None):
        super().__init__(parent,bg=CARD,width=101,height=166)
        self.pack_propagate(False)
        self.img=poster(101,140,title)
        tk.Label(self,image=self.img,bg=CARD,bd=0).pack()
        tk.Label(self,text=str(rank),fg="#FFFFFF",bg="#000000",font=font(34,True)).place(relx=.68,rely=.48)
        tk.Label(self,text=badge,fg="white",bg="#111111",font=font(8,False),padx=4).place(relx=1.0,rely=.0,anchor="ne")
        tk.Label(self,text=title,fg=TEXT,bg=CARD,font=font(9),anchor="w").pack(fill="x",padx=4)
        if command: self.bind("<Button-1>",lambda e:command())

class LiveCard(tk.Frame):
    def __init__(self,parent,upcoming=False):
        super().__init__(parent,bg=CARD,width=206,height=106)
        self.pack_propagate(False)
        if not upcoming: self.configure(bg="#26323A")
        tk.Label(self,text="●  Indian Premier League",fg=MUTED,bg=self["bg"],font=font(8)).pack(pady=(8,2))
        mid=tk.Frame(self,bg=self["bg"]); mid.pack()
        tk.Label(mid,text="🔵\nTeam A",fg=TEXT,bg=self["bg"],font=font(8),width=7).pack(side="left")
        center="4 Apr\n15:30" if upcoming else "0 - 0"
        tk.Label(mid,text=center,fg=TEAL if not upcoming else TEXT,bg=self["bg"],font=font(11,True)).pack(side="left",padx=8)
        tk.Label(mid,text="🔴\nTeam B",fg=TEXT,bg=self["bg"],font=font(8),width=7).pack(side="left")
        btn=tk.Button(self,text="Notify" if upcoming else "Details",bd=0,fg=GREEN if upcoming else MUTED,
                      bg="#1F4A3B" if upcoming else "#3A3D42",font=font(8,True),activebackground="#3A3D42")
        btn.pack(fill="x",padx=8,pady=(4,0),ipady=0)

class MainWindow:
    def __init__(self,root,client,backend):
        self.root=root; self.client=client; self.backend=backend
        self.hero_index=0
        self.featured=[("O.M – Operation Mole","OM Chapter 1: Udhira…"),("The Eminence in Shadow","Season 2"),("Operation Mole","Chapter 2")]
        self.images=[]
        self._build()
        self.client.homepage("trending", self._backend_home)

    def _build(self):
        self.outer=tk.Frame(self.root,bg=BG); self.outer.pack(fill="both",expand=True)
        self.canvas=tk.Canvas(self.outer,bg=BG,highlightthickness=0)
        self.scroll=tk.Frame(self.canvas,bg=BG)
        self.canvas.create_window((0,0),window=self.scroll,anchor="nw",width=390)
        self.canvas.pack(fill="both",expand=True)
        self.scroll.bind("<Configure>",lambda e:self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind_all("<MouseWheel>",lambda e:self.canvas.yview_scroll(int(-e.delta/120),"units"))
        self._topbar()
        self._tabs()
        self._hero()
        self._featured()
        self._section_live()
        self._section_movies()
        self._section_tv()
        self._nav()

    def _topbar(self):
        f=tk.Frame(self.scroll,bg=BG,height=43); f.pack(fill="x",padx=12); f.pack_propagate(False)
        tk.Label(f,text="⬇▶",fg=GREEN,bg=BG,font=font(16,True)).pack(side="left",padx=(0,8))
        search=tk.Frame(f,bg="#30343A",height=34); search.pack(side="left",fill="x",expand=True,pady=4)
        tk.Label(search,text="⌕",fg="white",bg="#30343A",font=font(15)).pack(side="left",padx=7)
        self.query=tk.Entry(search,bg="#30343A",fg="white",insertbackground="white",relief="flat",font=font(10))
        self.query.insert(0,"The Eminence in Shadow"); self.query.pack(side="left",fill="x",expand=True)
        tk.Button(search,text="Search",command=self.do_search,bd=0,bg="#30343A",fg=GREEN,font=font(10,True)).pack(side="right",padx=6)
        tk.Label(f,text="↑",fg="white",bg=PINK,font=font(13,True),width=2).pack(side="right",padx=(8,0))

    def _tabs(self):
        r=HRow(self.scroll,34); r.pack(fill="x"); 
        for t in ["Football","Trending","Movie","Anime","Cricket","TV"]:
            tk.Label(r.inner,text=t,fg=TEXT if t=="Trending" else "#B7BBC0",bg=BG,font=font(11,t=="Trending")).pack(side="left",padx=9)

    def _hero(self):
        self.hero=tk.Frame(self.scroll,bg="#3A2423",height=192); self.hero.pack(fill="x"); self.hero.pack_propagate(False)
        self.hero_img=placeholder(390,192,"O.M – Operation Mole","#6a2d27")
        self.hero_label=tk.Label(self.hero,image=self.hero_img,bg="#3A2423"); self.hero_label.pack(fill="both",expand=True)
        self.hero_title=tk.Label(self.hero,text="O.M – Operation Mole",fg="white",bg="#402321",font=font(18,True))
        self.hero_title.place(relx=.5,rely=.82,anchor="center")

    def _featured(self):
        r=HRow(self.scroll,64); r.pack(fill="x",pady=(0,12))
        for title,sub in self.featured:
            c=tk.Frame(r.inner,bg="#2A2D32",width=228,height=45); c.pack(side="left",padx=4,pady=8); c.pack_propagate(False)
            im=poster(37,52,sub); self.images.append(im)
            tk.Label(c,image=im,bg="#2A2D32").place(x=8,y=-7)
            tk.Label(c,text=title,fg="white",bg="#2A2D32",font=font(9,True),anchor="w").place(x=51,y=5,width=135)
            tk.Label(c,text="◉  | 2026 | Action",fg=MUTED,bg="#2A2D32",font=font(7)).place(x=51,y=23)
            tk.Button(c,text="▶",bd=0,bg=TEAL,fg="#0F1114",font=font(8,True)).place(x=197,y=11,width=23,height=23)

    def _header(self,title):
        f=tk.Frame(self.scroll,bg=BG,height=30); f.pack(fill="x",padx=12)
        tk.Label(f,text=title,fg="white",bg=BG,font=font(11,True)).pack(side="left")
        tk.Label(f,text="All ›",fg=MUTED,bg=BG,font=font(9)).pack(side="right")

    def _section_live(self):
        self._header("Live")
        r=HRow(self.scroll,120); r.pack(fill="x",pady=(0,10))
        LiveCard(r.inner).pack(side="left",padx=8); LiveCard(r.inner,True).pack(side="left",padx=8)

    def _chips(self):
        r=HRow(self.scroll,34); r.pack(fill="x")
        for i,t in enumerate(["Cinema","TOP Movies","Bollywood","South Indian","Hollywood…"]):
            tk.Label(r.inner,text=t,fg="white" if i==0 else MUTED,bg=CHIP if i==0 else BG,
                     font=font(9,i==0),padx=10,pady=5).pack(side="left",padx=4)

    def _section_movies(self):
        self._header("Trending Movies"); self._chips()
        r=HRow(self.scroll,176); r.pack(fill="x",pady=(2,14))
        for i,t in enumerate(["OM Chapter 1","The Eminence in Shadow","Operation Mole","Retro City","Kingdom"]):
            PosterCard(r.inner,t,i+1).pack(side="left",padx=4)

    def _section_tv(self):
        self._header("Trending TV Series")
        r=HRow(self.scroll,176); r.pack(fill="x",pady=(2,70))
        for i,t in enumerate(["Shadow Garden","The Boys","Wednesday","Arcane","Dark"]):
            PosterCard(r.inner,t,i+1,"TV").pack(side="left",padx=4)

    def _nav(self):
        n=tk.Frame(self.root,bg=NAV,height=58); n.place(relx=0,rely=1,relwidth=1,anchor="sw")
        for i,(icon,label,active) in enumerate([("⌂","Home",True),("⇩","Downloads",False),("●","Me",False)]):
            b=tk.Frame(n,bg=NAV); b.pack(side="left",fill="both",expand=True)
            tk.Label(b,text=icon,fg=TEAL if active else MUTED,bg=NAV,font=font(17,True)).pack(pady=(5,0))
            tk.Label(b,text=label,fg="white" if active else MUTED,bg=NAV,font=font(8,active)).pack()
        tk.Label(n,text="1",fg="white",bg=GREEN,font=font(7,True)).place(relx=.48,rely=.08)
        tk.Label(n,text="•",fg=PINK,bg=NAV,font=font(12,True)).place(relx=.82,rely=.04)

    def do_search(self):
        q=self.query.get().strip()
        if q: self.client.search(q,self._backend_search)

    def _backend_home(self,response):
        # UI intentionally remains usable if a provider is unavailable.
        if not response or not response.get("ok"): return
        items=(response.get("data") or {}).get("items",[])
        if not items:return
        # Update hero title from real backend data without replacing the visual layout.
        first=items[0]
        self.root.after(0,lambda:self.hero_title.config(text=first.get("title","O.M – Operation Mole")))

    def _backend_search(self,response):
        if not response or not response.get("ok"): return
        items=response.get("data") or []
        if items:
            title=items[0].get("title","")
            self.root.after(0,lambda:self.hero_title.config(text=title))
